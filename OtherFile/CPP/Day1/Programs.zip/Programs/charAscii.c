#include<stdio.h>
int main()
{
   int i;
   for(i=0; i<256 ; i++)
      printf("  %c - %d", i,i);

   printf("\n The End..");
   return 0;

  }
