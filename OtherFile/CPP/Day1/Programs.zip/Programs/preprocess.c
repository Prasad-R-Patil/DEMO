#include<stdio.h>
#define MAX 500

int main()
{
   printf("\n Preprocessor directive..");
   return 0;
}
