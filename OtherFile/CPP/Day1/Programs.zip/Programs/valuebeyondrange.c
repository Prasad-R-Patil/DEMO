#include<stdio.h>
#include<limits.h>
int main()
{
   int a = INT_MAX;

  
 // unsigned int b = 4000000000;

  printf("\n a = %d", a);
  a  =  a + 1;
  printf("\n a = %d", a);

 // printf("\n b = %u", b);

  return 0;
}


//      
