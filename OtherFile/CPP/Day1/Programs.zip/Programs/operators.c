#include<stdio.h>

int main()
{
    int num1, num2 , num3, sum;

   sum = (num1 = 2, num2 = 4, num3 = 5, num1+num2+num3);
  
   printf("\n  %d", sum > 15);

  return 0;
}


condition expression uses relational operators( >, <, >=, <=)
      (==  equality)


   relational operators return 0 or 1

int num1 = 20;

if(num1 = 10)
   printf("\n equal to 10");
else
  printf("\n not equal to 10");


any non-zero value is true
zero is false


____________________________________________________________










