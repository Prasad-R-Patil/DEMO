#include<stdio.h>
int main()
{
   int num1 = 20, num2 = 9;

  if((num1==20) || (num2 = 30))
     printf("\n True");
  else
     printf("\n False");
   
   printf("\n num1 = %d   num2 = %d", num1, num2);
   printf("\n The end...");
   return 0;
}
